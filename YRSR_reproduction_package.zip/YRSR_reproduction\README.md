# Reproduction Package - ESCI step (Yellow River Source Region)

Minimal package for verifying the ESCI (Environmental Sustainability Capacity Index) results
reported in the manuscript: normalization, entropy + AHP weighting, natural-breaks
classification, and the county-level statistics.

## Structure

    00_docs/        Reproduction manuals and environment specification (original language: Chinese)
    01_code/        Analysis pipeline (s01_prepare.py ... s10_report.py, common.py, geo.py, stats.py)
    02_parameters/  Model parameter tables (carbon pools, alpha sensitivity, per-year threat/sensitivity CSVs)
    03_results/     ESCI results for the analysis year (2019)
    04_manifest/    File list of the raw and intermediate inputs (not copied)

## 03_results/05_ESCI

    ESCI_2019.tif                 continuous ESCI surface (analysis year)
    ESCI5_2019.tif                five-class classification
    esci_breaks_fitted_2019.json  natural-break bounds
    county_area_2019.csv          area proportions of ESCI classes by county
    esci_stats.csv                summary statistics
    sensitivity_alpha.csv         weights under alternative combination coefficients

    The full 2000-2020 annual series is not shipped; `s08_esci.py` regenerates it from the
    parameters and upstream outputs.

## How to run

1. Install the environment in `00_docs/requirements.txt` (original run: ArcGIS 10.8 / Python 2.7 for rasters).
2. Follow `00_docs/Reproduction_Manual.md` and `00_docs/Full_Reproduction_Guide.md`.
3. Run s01_prepare -> s02_rusle -> s03_invest -> s04_trend -> s05_omgd -> s06_leri ->
   s07_network -> s08_esci -> s09_sdg -> s10_report; s08_esci reproduces this step.
4. Compare with `00_docs/Expected_Results_Benchmark.md`.

## Scope

- Included: code, all parameter tables, ESCI results for 2019, and the input manifest (~7 MB without .git).
- Not included: raw inputs (~489 GB), intermediate products (~116 GB), the annual ESCI series for
  2000-2018 and 2020, and the result rasters of the other analysis steps. Their paths, sizes and dates
  are listed in `04_manifest/input_and_process_file_list.csv`.
- File and folder names are in English; manuals in `00_docs` are the original Chinese documents.